
public class Predictor32000 extends Predictor {
/* 	
	PC_bits : Number of bits taken from PC to index Pattern History Table
	k_bits : size of GHR
	n1_bits : Number of bits taken from PC to index GHR Table
	SC_bits : Number of bits in saturating counter
*/
	int pc_n_bits = 6, k_bits = 7, pc_n1_bits = 10, sc_bits = 3;
	public Table pattern_history;
	public Table global_history;
	
	public Predictor32000() {
		pattern_history = new Table(1<<(pc_n_bits + k_bits), sc_bits);
		global_history = new Table(1<<pc_n1_bits, k_bits);
	}

	public void Train(long address, boolean outcome, boolean predict) {
/*	First we need to find the index of Global History Table and access k-bits of GHR,
	then we use the k-bits and pc_n_bits to calculate index of Pattern Histroy Table.
*/
		/*
		GHT_index : index of an entry in Global History Table
		GHR_val : val stored in the corresponding index entry
		PC_n_val : integer value of last n bits of PC
		PHT_index : Index of an entry in Pattern History Table
		SC_state : state of saturating counter stored in PHT
		*/
		int ght_index = ((int)address)&((1<<pc_n1_bits)-1);
		int ghr_val = global_history.getInteger(ght_index, 0, k_bits-1);
		int pc_n_val = ((int)address)&((1<<pc_n_bits)-1);
		int pht_index = (pc_n_val<<k_bits) + ghr_val;
		int sc_state = pattern_history.getInteger(pht_index, 0, sc_bits-1);
		ghr_val = ghr_val>>1;
		if (outcome) {
			sc_state++;
			sc_state = Math.min(sc_state, (1<<sc_bits)-1);
			ghr_val = ghr_val + (1<<(k_bits-1));
		}
		else{
			sc_state--;
			sc_state = Math.max(sc_state, 0);
			ghr_val = ghr_val + 0;
		}
				
		pattern_history.setInteger(pht_index, 0, sc_bits-1, sc_state);
		global_history.setInteger(ght_index, 0, k_bits-1, ghr_val);
	}

	public boolean predict(long address){
		int ght_index = ((int)address)&((1<<pc_n1_bits)-1);
		int ghr_val = global_history.getInteger(ght_index, 0, k_bits-1);
		int pc_n_val = ((int)address)&((1<<pc_n_bits)-1);
		int pht_index = (pc_n_val<<k_bits) + ghr_val;
		return pattern_history.getBit(pht_index, 0);
	}

}
